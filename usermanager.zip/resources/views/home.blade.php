@extends('layouts.app')

@section('content')
    <hr>
    <div id="app">
        <users></users>
    </div>
@endsection