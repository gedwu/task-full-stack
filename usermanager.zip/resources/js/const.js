export const settings = {
    RANDOM_USER_URL: 'https://jsonplaceholder.typicode.com/users/'
};