<form action="#" @submit.prevent="edit ? updateUser(user.id) : createUser()">
    <div class="form-group">
        <label>Name</label>
        <input v-model="user.name" type="text" name="name" class="form-control">
    </div>
    <div class="form-group">
        <label>Email</label>
        <input v-model="user.email" type="email" name="email" class="form-control">
    </div>
    <div class="form-group">
        <label>Phone Number</label>
        <input v-model="user.phone" type="text" name="phone" class="form-control">
    </div>
    <div class="form-group">
        <label class="radio-inline">
            <input type="radio" v-model="user.gender" v-bind:value="'m'" checked>
            Male
        </label>
        <label class="radio-inline">
            <input type="radio" v-model="user.gender" v-bind:value="'f'">
            Female
        </label>
    </div>
    <div class="form-group">
        <label class="radio-inline">
            <input type="radio" v-model="user.status" v-bind:value="1" checked>
            Active
        </label>
        <label class="radio-inline">
            <input type="radio" v-model="user.status" v-bind:value="0">
            Inactive
        </label>
    </div>
    <div class="form-group">
        <button type="button" @click="randomizeUser()" class="btn btn-success">Randomize User</button>
        <button v-show="!edit" type="submit" class="btn btn-primary">Add User</button>
        <button v-show="edit" type="submit" class="btn btn-primary">Edit User</button>
    </div>
</form>
